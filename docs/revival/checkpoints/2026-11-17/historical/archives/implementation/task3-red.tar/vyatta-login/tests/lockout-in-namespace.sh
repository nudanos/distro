#!/bin/bash
# Run as root inside a dedicated private mount namespace on Debian.
set -euo pipefail
repo=$(cd "$(dirname "$0")/.." && pwd)
work=$(mktemp -d)
mount --make-rprivate /
mkdir -p "$work"/{profiles,templates,pam,debconf,cache,tallies}
cp -a /usr/share/pam-configs/. "$work/profiles/"
cp -a /etc/pam.d/. "$work/pam/"
cp -a /var/lib/pam/. "$work/cache/"
cp -a /var/cache/debconf/. "$work/debconf/"
cp -a "$repo"/usr/share/pam-configs/*.template "$work/templates/"
mount --bind "$work/profiles" /usr/share/pam-configs
mount --bind "$work/pam" /etc/pam.d
mount --bind "$work/cache" /var/lib/pam
mount --bind "$work/debconf" /var/cache/debconf
# The nested shell sets up configd template paths without creating /opt/vyatta on the VM.
mkdir -p "$work/opt/vyatta/share/pam-configs"
mount --bind "$work/opt" /opt
mount --bind "$work/templates" /opt/vyatta/share/pam-configs
mount -t tmpfs tmpfs /run
mkdir /run/faillock
mount --bind "$work/tallies" /run/faillock

# Use temporary passwd/shadow files for a local user and a root recovery account.
cp /etc/passwd "$work/passwd"
cp /etc/shadow "$work/shadow"
hash=$(/usr/bin/python3 -c 'import crypt_r; print(crypt_r.crypt("correct", "$6$test$"))')
echo 'nudanos-lockout-user:x:24680:100::/nonexistent:/bin/false' >>"$work/passwd"
printf 'nudanos-lockout-user:%s:20000:0:99999:7:::\n' "$hash" >>"$work/shadow"
sed -i "s|^root:[^:]*:|root:$hash:|" "$work/shadow"
mount --bind "$work/passwd" /etc/passwd
mount --bind "$work/shadow" /etc/shadow
echo '@include common-auth' > /etc/pam.d/nudanos-lockout-test
cc -Wall -Wextra -Werror -o "$work/pam-auth" "$repo/tests/pam-auth.c" -lpam
export PERL5LIB="$repo/tests/perl"
export PATH="/usr/sbin:$PATH"

auth() { "$work/pam-auth" "$1" "$2"; }
expect_rejected() { if auth "$1" "$2"; then echo "unexpected acceptance for $1" >&2; exit 1; fi; }
update() { perl "$repo/scripts/system/vyatta_update_login.pl" --system; }

# Correct password succeeds and a successful authentication clears failures.
u=nudanos-lockout-user
auth "$u" correct
export TEST_ENABLE_LOCKOUT=1
update
auth "$u" correct || { echo 'valid authentication broken after enabling lockout' >&2; exit 1; }
expect_rejected "$u" wrong
auth "$u" correct
expect_rejected "$u" wrong
expect_rejected "$u" wrong
expect_rejected "$u" correct
# Root remains available, and the recovery RPC clears the local user's record.
expect_rejected root wrong
expect_rejected root wrong
auth root correct
printf '{"user":"%s"}' "$u" | perl "$repo/scripts/system/vyatta_tally_rpc" --action=reset
auth "$u" correct
# Deactivation returns the local stack to stock authentication.
expect_rejected "$u" wrong
expect_rejected "$u" wrong
unset TEST_ENABLE_LOCKOUT
update
auth "$u" correct
