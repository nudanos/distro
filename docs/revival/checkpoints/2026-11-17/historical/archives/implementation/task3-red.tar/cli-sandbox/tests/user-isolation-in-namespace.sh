#!/bin/bash
# Exercise the real hook with fake host paths in a private mount namespace.
set -euo pipefail
repo=$(cd "$(dirname "$0")/.." && pwd)
fixture=$(mktemp -d)
mount --make-rprivate /
mkdir -p "$fixture"/{opt,profiles,bin,pam,root}
mount --bind "$fixture/opt" /opt
mount --bind "$fixture/profiles" /usr/share/pam-configs
mount --bind "$fixture/pam" /etc/pam.d
export PATH="$fixture/bin:$PATH"
export TEST_FIXTURE="$fixture"
cat > "$fixture/bin/pam-auth-update" <<'STUB'
#!/bin/sh
[ "${FAIL_UPDATE:-0}" = 0 ] || exit 1
case " $* " in
    *" --remove "*) : > /etc/pam.d/common-session;;
    *) [ "${IGNORE_UPDATE:-0}" = 0 ] || exit 0
       echo 'session required pam_sandbox.so' > /etc/pam.d/common-session;;
esac
STUB
chmod +x "$fixture/bin/pam-auth-update"
hook="$repo/tmplscripts/system/login/user_isolation.sh"
should_fail() {
    if bash "$hook" "$@"; then
        echo "sandbox hook reported success for a failed $* operation" >&2
        return 1
    fi
}

# Missing package assets must block activation.
should_fail enable
test ! -e /usr/share/pam-configs/sandbox
# Deactivation must retain the source for retry if PAM regeneration fails.
cp "$repo/src/pam_sandbox/pam-configs/sandbox" /usr/share/pam-configs/sandbox
echo 'session required pam_sandbox.so' > /etc/pam.d/common-session
FAIL_UPDATE=1 should_fail disable
test -f /usr/share/pam-configs/sandbox
grep -q pam_sandbox.so /etc/pam.d/common-session
bash "$hook" disable
test ! -e /usr/share/pam-configs/sandbox
! grep -q pam_sandbox.so /etc/pam.d/common-session

# Non-Debian integration must reject activation and leave PAM alone.
echo 'ID=arch' > "$fixture/os-release"
mount --bind "$fixture/os-release" "$(readlink -f /etc/os-release)"
should_fail enable
test ! -e /usr/share/pam-configs/sandbox
