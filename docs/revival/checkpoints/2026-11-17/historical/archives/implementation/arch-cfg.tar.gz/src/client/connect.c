/*
   Copyright (c) 2018-2020, AT&T Intellectual Property. All rights reserved.
   Copyright (c) 2013-2014 by Brocade Communications Systems, Inc.
   All rights reserved.
 *
 * SPDX-License-Identifier: LGPL-2.1-only
*/

#include <argz.h>
#include <envz.h>
#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#include <vyatta-util/map.h>
#include <vyatta-util/vector.h>

#include "rpc.h"
#include "connect.h"
#include "log.h"
#include "error.h"
#include "internal.h"

#define ENFORCE_STRING_ENTRIES 1
#define IGNORE_NON_STRING_ENTRIES 0

#define DEFAULT_CONFIG_SOCKET "/var/run/vyatta/configd/main.sock"

#define DEBUG 1
#undef DEBUG

#ifdef DEBUG
static void msg_json(const json_t *jobj, const char *pfx)
{
	char *jstr = json_dumps(jobj, 0);
	if (jstr) {
		msg_out("%s: %s\n", pfx, jstr);
		free(jstr);
	}
}
#else
#define msg_json(...)
#endif

// response_free() would typically only be called on error, as otherwise the
// allocated resource (string, map or vector) is passed to the caller of the
// relevant get_str/map/vector() function.  However, if called, it should
// clean up properly.
void response_free(struct response *resp)
{
	switch (resp->type) {
		case INT:
			break;
		case STRING:
			free(resp->result.str_val);
			break;
		case VECTOR:
			vector_free(resp->result.v);
			break;
		case MAP:
			map_free(resp->result.m);
			break;
		case ERROR:
			free(resp->result.str_val);
			break;
		case MGMTERROR:
			mgmt_err_list_free(&resp->result.mgmt_errs);
			break;
	}
}


/* There are no communication timeouts as some operations
 * (e.g., commit) can take an unbounded amount of time.
 */
int configd_open_connection(struct configd_conn *conn)
{
	int flags;
	socklen_t len;
	int local_errno;
	struct sockaddr_un configd = { .sun_family = AF_UNIX };

	const char *sock_addr = getenv("VYATTA_CONFIG_SOCKET");
	if (sock_addr == NULL) {
		sock_addr = DEFAULT_CONFIG_SOCKET;
	}
	snprintf(configd.sun_path, sizeof(configd.sun_path), "%s", sock_addr);

	if (!conn) {
		errno = EFAULT;
		return -1;
	}

	memset(conn, 0, sizeof(*conn));
	conn->fd = socket(AF_UNIX, SOCK_STREAM, 0);
	if (conn->fd == -1)
		return -1;
	if ((flags = fcntl(conn->fd, F_GETFD)) != -1)
		fcntl(conn->fd, F_SETFD, flags | FD_CLOEXEC);

	len = SUN_LEN(&configd);
	if (connect(conn->fd, (struct sockaddr *)&configd, len) == -1) {
		local_errno = errno;
		close(conn->fd);
		goto error;
	}

	conn->fp = fdopen(conn->fd, "r+");
	if (!conn->fp) {
		local_errno = errno;
		close(conn->fd);
		msg_err("Unable to open socket stream to configd\n");
		goto error;
	}
	conn->session_id = strdup("");
	return 0;

error:
	configd_close_connection(conn);
	errno = local_errno;
	return -1;
}

void configd_close_connection(struct configd_conn *conn)
{
	if (conn->fp)
		fclose(conn->fp);

	/* don't close conn->fd - fclose will have done it */

	free(conn->session_id);
}


int configd_set_session_id(struct configd_conn *conn, const char *session_id)
{
	if (!conn || !session_id) {
		errno = EFAULT;
		return -1;
	}

	if (conn->session_id)
		free(conn->session_id);

	conn->session_id = strdup(session_id);
	return 0;
}


int send_request(struct configd_conn *conn, const struct request *req)
{
	json_t *jreq;
	json_error_t jerr;
	int result = -1;
	char *jstr;

	if (!conn || !req || !req->args) {
		errno = EFAULT;
		return -1;
	}

	/* Consumes ref to req->args on success */
	jreq = json_pack_ex(&jerr, 0, "{s:s, s:o, s:i}",
			    "method", req->fn,
			    "params", req->args,
			    "id", ++(conn->req_id));
	if (!jreq || json_is_null(jreq)) {
		msg_err("Unable to pack configd request: %s\n", jerr.text);
		return -1;
	}

	msg_json(jreq, __func__); /* debugging */
	jstr = json_dumps(jreq, JSON_COMPACT);
	if (jstr) {
		result = write(conn->fd, jstr, strlen(jstr));
		free(jstr);
	}

	json_decref(jreq);
	return result;
}

static struct vector *jarray_to_vector(json_t *jobj)
{
	int local_errno = 0;
	struct vector *v = NULL;
	size_t arr_len, i;
	size_t argz_len = 0;
	char *argz = NULL;

	arr_len = json_array_size(jobj);
	if (argz_create_sep("", 0, &argz, &argz_len)) {
		errno = ENOMEM;
		return NULL;
	}

	for (i = 0; i < arr_len; ++i) {
		json_t *jval;
		const char *vstr;

		jval = json_array_get(jobj, i);
		vstr = json_string_value(jval);
		if (!vstr) {
			local_errno = EINVAL;
			goto error;
		}

		if (argz_add(&argz, &argz_len, vstr)) {
			local_errno = ENOMEM;
			goto error;
		}
	}

	v = vector_new(argz, argz_len);
	if (!v) {
		local_errno = ENOMEM;
		goto error;
	}
	goto done;

error:
	free(argz);
done:
	errno = local_errno;
	return v;
}

// Take a JSON array object that is presumed to be a list of single entry
// maps and return a single map containing all the single entries.
// Assumption is that there will not be duplicate keys in source JSON.
static struct map *jarray_to_map(json_t *jobj)
{
	struct map *m = NULL;
	int local_errno = 0;
	size_t arr_len, i;
	size_t argz_len = 0;
	char *argz = NULL;

	arr_len = json_array_size(jobj);
	if (argz_create_sep("", 0, &argz, &argz_len)) {
		errno = ENOMEM;
		return NULL;
	}

	for (i = 0; i < arr_len; ++i) {
		json_t *jval, *jmap;
		const char *key;

		jmap = json_array_get(jobj, i);
		if (!jmap) {
			local_errno = EINVAL;
			goto error;
		}

		json_object_foreach(jmap, key, jval) {
			const char *vstr;

			vstr = json_string_value(jval);
			if (!vstr) {
				local_errno = EINVAL;
				goto error;
			}

			if (envz_add(&argz, &argz_len, key, vstr)) {
				local_errno = ENOMEM;
				goto error;
			}
		}
	}

	m = map_new(argz, argz_len);
	if (!m) {
		local_errno = ENOMEM;
		goto error;
	}
	goto done;

error:
	free(argz);
done:
	errno = local_errno;
	return m;
}

// In some cases we expect all elements to be strings, but in others the type
// may vary.  Use 'only_allow_strings' to determine if a non-string element
// should be treated as an error or not.
static struct map *jobj_to_map(json_t *jobj, int only_allow_strings)
{
	int local_errno = 0;
	struct map *m = NULL;
	size_t argz_len = 0;
	char *argz = NULL;

	const char *key;
	json_t *jval;

	if (argz_create_sep("", 0, &argz, &argz_len)) {
		errno = ENOMEM;
		return NULL;
	}

	json_object_foreach(jobj, key, jval) {
		const char *vstr;

		vstr = json_string_value(jval);
		if (!vstr) {
			if (only_allow_strings) {
				local_errno = EINVAL;
				goto error;
			}
			continue;
		}
		if (envz_add(&argz, &argz_len, key, vstr)) {
			local_errno = errno;
			goto error;
		}
	}

	m = map_new(argz, argz_len);
	if (!m) {
		local_errno = ENOMEM;
		goto error;
	}
	goto done;

error:
	free(argz);
done:
	errno = local_errno;
	return m;
}

// jobj_is_null() - return true if jobj is null or if jobj is valid but contains
// the 'null' value (ie json_is_null() returned 'true')
//
// Note json_is_null() returns false if object passed is itself null so be warned.
static int jobj_is_null(json_t *jobj) {
	return ((jobj == NULL) || json_is_null(jobj));
}

// jobj_is_not_null() - return true if jobj contains a valid, non-null JSON
// object.
static int jobj_is_not_null(json_t *jobj) {
	return (!jobj_is_null(jobj));
}

// contains_non_null_entry_for() - return true (!0) if jobj exists and
// contains a non-null entry for the given key.
static int contains_non_null_entry_for(json_t *jobj, const char *key) {
	return jobj_is_not_null(json_object_get(jobj, key));
}

// Extract the contents, if any, of the <error-info> section of a mgmt_error
// into a map.
//
// Example JSON format for error-info:
//
//       "error-info" : [
//          {
//             "bad-element" : "logan"
//          },
//          {
//             "bad-attribute" : "just testing"
//          }
//       ],

static int extract_mgmt_error_info_as_map(
	json_t *jobj,
	struct map **info)
{
	json_t *jinfo = NULL;

	*info = NULL;

	// If we have no error-info, that's ok.
	jinfo = json_object_get(jobj, "error-info");
	if (jobj_is_null(jinfo)) {
		return 0;
	}

	*info = jarray_to_map(jinfo);

	return (*info) ? 0 : -1;
}

// Return 0 on success, -1 for failure.  Frees any allocated resources for all
// extracted errors on failure.
static int process_errlist_array(
	struct configd_mgmt_err_list *errlist,
	json_t *jarray,
	int arr_len)
{
	struct map *fields = NULL;
	int retval = 0;
	int i = 0;

	errlist->me_list = calloc(arr_len, sizeof(struct configd_mgmt_error *));
	if (errlist->me_list == NULL) {
		msg_err("Unable to allocate memory for error list\n");
		return -1;
	}

	for (i = 0; i < arr_len; i++) {
		json_t *jmap;
		struct map *info = NULL;

		jmap = json_array_get(jarray, i);
		if (!json_is_object(jmap)) {
			msg_err("Unexpected JSON data type for configd mgmt-error\n");
			goto error;
		}

		// Get fields, info
		fields = jobj_to_map(jmap, IGNORE_NON_STRING_ENTRIES);
		if (!fields) {
			msg_err("Unable to extract configd mgmt-error response\n");
			goto error;
		}

		retval = extract_mgmt_error_info_as_map(jmap, &info);
		if (retval != 0) {
			msg_err("Unable to extract configd mgmt-error info element(s).");
			goto error;
		}

		errlist->me_list[i] = calloc(1, sizeof(struct configd_mgmt_error));
		if (errlist->me_list[i] == NULL) {
			msg_err("Unable to allocate memory for mgmt-error\n");
			goto error;
		}
		errlist->num_entries++;

		retval = configd_mgmt_error_set_from_maps(
			errlist->me_list[i], fields, &info);
		map_free(fields);
		fields = NULL;
		if (retval != 0) {
			msg_err("Unable to set error from data");
			goto error;
		}
	}

	return 0;

error:
	if (fields != NULL) {
		map_free(fields);
	}
	for (i = 0; i < errlist->num_entries; i ++) {
		configd_mgmt_error_free(errlist->me_list[i]);
		free(errlist->me_list[i]);
	}
	free(errlist->me_list);
	errlist->me_list = NULL;
	errlist->num_entries = 0;

	return -1;
}

static int extract_mgmt_error_list(json_t *jobj, struct response *resp) {
	json_t *jarray = NULL;
	int arr_len = 0;
	int retval = 0;

	resp->type = MGMTERROR;

	if (!json_is_object(jobj)) {
		msg_err("configd mgmt-error-list response must be a map\n");
		return -1;
	}
	jarray = json_object_get(jobj, "error-list");
	if (!json_is_array(jarray)) {
		msg_err("configd 'mgmterrorlist' doesn't contain 'error-list'\n");
		return -1;
	}

	arr_len = json_array_size(jarray);
	if (arr_len == 0) {
		msg_err("configd error-list is empty\n");
		return -1;
	}

	// Need to create list of configd_mgmt_error objects from JSON array.
	struct configd_mgmt_err_list errlist = { .num_entries=0, .me_list=NULL };
	retval = process_errlist_array(&errlist, jarray, arr_len);

	resp->result.mgmt_errs.num_entries = errlist.num_entries;
	resp->result.mgmt_errs.me_list = errlist.me_list;

	return retval;
}

static int extract_result(json_t *jresult, struct response *resp) {
	int retval = 0;

	int resp_type = json_typeof(jresult);
	switch (resp_type) {
		case JSON_TRUE:
			resp->type = INT;
			resp->result.int_val = 1;
			break;
		case JSON_FALSE:
			resp->type = INT;
			resp->result.int_val = 0;
			break;
		case JSON_INTEGER:
			resp->type = INT;
			resp->result.int_val = json_integer_value(jresult);
			break;
		case JSON_STRING:
			resp->type = STRING;
			resp->result.str_val = local_strdup(json_string_value(jresult));
			break;
		case JSON_ARRAY:
			resp->type = VECTOR;
			resp->result.v = jarray_to_vector(jresult);
			if (!resp->result.v) {
				retval = -1;
			}
			break;
		case JSON_OBJECT:
			resp->type = MAP;
			resp->result.m = jobj_to_map(jresult, ENFORCE_STRING_ENTRIES);
			if (!resp->result.m) {
				retval = -1;
			}
			break;
		default:
			msg_err("Unhandled configd result type %d\n", resp_type);
			break;
	}

	return retval;
}

int recv_response(struct configd_conn *conn, struct response *resp)
{
	json_t *jresp = NULL;
	json_t *jresult;
	json_t *jobj;
	int ret = -1;
	json_error_t jerr;

	if (!conn || !resp) {
		errno = EFAULT;
		return -1;
	}

	memset(&resp->result, 0, sizeof(resp->result));
	while (jresp == NULL && !feof(conn->fp))
		jresp = json_loadf(conn->fp, JSON_DISABLE_EOF_CHECK, &jerr);

	if (!jresp || json_is_null(jresp)) {
		msg_err("%s: %s\n", __func__, jerr.text);
		return -1;
	}

	msg_json(jresp, __func__); /* debugging */

	if (contains_non_null_entry_for(jresp, "result")) {
		jresult = json_object_get(jresp, "result");
		ret = extract_result(jresult, resp);
		if (ret != 0) {
			goto done;
		}
	} else if (contains_non_null_entry_for(jresp, "error")) {
		resp->type = ERROR;
		jobj = json_object_get(jresp, "error");
		if (!json_is_string(jobj)) {
			msg_err("configd error response must be a string\n");
			goto done;
		}
		resp->result.str_val = local_strdup(json_string_value(jobj));
	} else if (contains_non_null_entry_for(jresp, "mgmterrorlist")) {
		// This field should always be present, but will be an empty list if
		// we got a valid result, or a 'basic' error above.  This means it
		// should be checked last in this if else clause.
		jobj = json_object_get(jresp, "mgmterrorlist");
		ret = extract_mgmt_error_list(jobj, resp);
		if (ret != 0) {
			msg_err("Unable to extract mgmt error.");
			goto done;
		}
	}

	jobj = json_object_get(jresp, "id");
	if (!json_is_integer(jobj)) {
		msg_err("configd response id must be an integer\n");
		goto done;
	}
	resp->id = json_integer_value(jobj);
	ret = (conn->req_id == resp->id) ? 0 : -1;
done:
	json_decref(jresp);
	return ret;
}

// handle_rpc_error
//
// Handle returned error, which may be a simple string, or a map containing
// relevant fields of a MgmtError object.
static void handle_rpc_error(struct configd_error *error, struct response *resp)
{
	if (error) {
		error_setf(error, "%s\n", resp->result.str_val);
		return;
	}
}

int get_int(struct configd_conn *conn, const struct request *req, struct configd_error *error)
{
	struct response resp;

	if (!conn || !req) {
		errno = EFAULT;
		return -1;
	}

	if (send_request(conn, req) == -1) {
		if (!error)
			msg_err("Error sending configd int request\n");
		error_setf(error, "Error sending request");
		return -1;
	}

	if (recv_response(conn, &resp) == -1) {
		if (!error)
			msg_err("Error receiving configd int response\n");
		error_setf(error, "Error receiving response");
		goto error;
	}

	switch (resp.type) {
	case INT:
		return resp.result.int_val;
	case ERROR:
		handle_rpc_error(error, &resp);
		break;
	case MGMTERROR:
		error_set_from_mgmt_error_list(error, &resp.result.mgmt_errs, req->fn);
		break;
	default:
		break;

	}
error:
	response_free(&resp);
	return -1;
}

char *get_str(struct configd_conn *conn, const struct request *req, struct configd_error *error)
{
	struct response resp;

	if (!conn || !req) {
		errno = EFAULT;
		return NULL;
	}

	if (send_request(conn, req) == -1) {
		if (!error)
			msg_err("Error sending configd string request\n");
		error_setf(error, "Error sending request");
		return NULL;
	}

	if (recv_response(conn, &resp) == -1) {
		if (!error)
			msg_err("Error receiving configd string response\n");
		error_setf(error, "Error receiving response");
		goto error;
	}

	switch (resp.type) {
	case STRING:
		return resp.result.str_val;
	case ERROR:
		handle_rpc_error(error, &resp);
		break;
	case MGMTERROR:
		error_set_from_mgmt_error_list(error, &resp.result.mgmt_errs, req->fn);
		break;
	default:
		break;

	}
error:
	response_free(&resp);
	return NULL;
}

struct vector *get_vector(struct configd_conn *conn, const struct request *req, struct configd_error *error)
{
	struct response resp;

	if (!conn || !req) {
		errno = EFAULT;
		return NULL;
	}

	if (send_request(conn, req) == -1) {
		if (!error)
			msg_err("Error sending configd vector request\n");
		error_setf(error, "Error sending request");
		return NULL;
	}

	if (recv_response(conn, &resp) == -1) {
		if (!error)
			msg_err("Error receiving configd vector response\n");
		error_setf(error, "Error receiving response");
		goto error;
	}

	switch (resp.type) {
	case VECTOR:
		return resp.result.v;
	case ERROR:
		handle_rpc_error(error, &resp);
		break;
	case MGMTERROR:
		error_set_from_mgmt_error_list(error, &resp.result.mgmt_errs, req->fn);
		break;
	default:
		break;

	}
error:
	response_free(&resp);
	return NULL;
}

struct map *get_map(struct configd_conn *conn, const struct request *req, struct configd_error *error)
{
	struct response resp;

	if (!conn || !req) {
		errno = EFAULT;
		return NULL;
	}

	if (send_request(conn, req) == -1) {
		if (!error)
			msg_err("Error sending configd map request\n");
		error_setf(error, "Error sending request");
		return NULL;
	}

	if (recv_response(conn, &resp) == -1) {
		if (!error)
			msg_err("Error receiving configd map response\n");
		error_setf(error, "Error receiving response");
		goto error;
	}

	switch (resp.type) {
	case MAP:
		return resp.result.m;
	case ERROR:
		handle_rpc_error(error, &resp);
		break;
	case MGMTERROR:
		error_set_from_mgmt_error_list(error, &resp.result.mgmt_errs, req->fn);
		break;
	default:
		break;

	}
error:
	response_free(&resp);
	return NULL;
}
