#!/bin/bash
# Run as root inside a dedicated private mount namespace on Debian.
set -euo pipefail
if [ "$(readlink /proc/self/ns/mnt)" = "$(readlink /proc/1/ns/mnt)" ]; then
    echo 'Run with sudo unshare -m --propagation private bash' >&2
    exit 2
fi
repo=$(cd "$(dirname "$0")/.." && pwd)
work=$(mktemp -d)
mount --make-rprivate /
mkdir -p "$work"/{profiles,pam,debconf,cache,tallies}
cp -a /usr/share/pam-configs/. "$work/profiles/"
cp -a /etc/pam.d/. "$work/pam/"
cp -a /var/lib/pam/. "$work/cache/"
cp -a /var/cache/debconf/. "$work/debconf/"
mount --bind "$work/profiles" /usr/share/pam-configs
mount --bind "$work/pam" /etc/pam.d
mount --bind "$work/cache" /var/lib/pam
mount --bind "$work/debconf" /var/cache/debconf
mount -t tmpfs tmpfs /run
mkdir /run/vyatta-faillock
mount --bind "$work/tallies" /run/vyatta-faillock

# Use temporary passwd/shadow files for a local user and a root recovery account.
cp /etc/passwd "$work/passwd"
hash=$(/usr/bin/python3 -c 'import crypt_r; print(crypt_r.crypt("correct", "$6$test$"))')
echo 'nudanos-lockout-user:x:24680:100::/nonexistent:/bin/false' >>"$work/passwd"
printf 'nudanos-lockout-user:%s:20000:0:99999:7:::\n' "$hash" >>"$work/shadow"
printf 'root:%s:20000:0:99999:7:::\n' "$hash" >>"$work/shadow"
mount --bind "$work/passwd" /etc/passwd
mount --bind "$work/shadow" /etc/shadow
echo '@include common-auth' > /etc/pam.d/nudanos-lockout-test
cc -Wall -Wextra -Werror -o "$work/pam-auth" "$repo/tests/pam-auth.c" -lpam
export PERL5LIB="$repo/lib:$repo/tests/perl"
export PATH="/usr/sbin:$PATH"

auth() { "$work/pam-auth" "$1" "$2"; }
expect_rejected() { if auth "$1" "$2"; then echo "unexpected acceptance for $1" >&2; exit 1; fi; }
update() { perl "$repo/scripts/system/vyatta_update_login.pl" --system; }

# Correct password succeeds and a successful authentication clears failures.
u=nudanos-lockout-user
auth "$u" correct
cp /etc/pam.d/common-auth "$work/auth.original"
export TEST_ENABLE_LOCKOUT=1
# Missing native prerequisites fail before updating the stack.
touch "$work/disabled-faillock"
mount --bind "$work/disabled-faillock" /usr/sbin/faillock
if update; then echo 'enabled without the faillock utility' >&2; exit 1; fi
umount /usr/sbin/faillock
# Reject unsupported parameters and mixed/configured remote authentication.
if TEST_DENY=1025 update; then echo 'accepted an invalid attempt count' >&2; exit 1; fi
if TEST_UNLOCK=604801 update; then echo 'accepted an invalid duration' >&2; exit 1; fi
if TEST_REMOTE=1 update; then echo 'enabled alongside a remote auth chain' >&2; exit 1; fi
cmp "$work/auth.original" /etc/pam.d/common-auth
update
auth "$u" correct || { echo 'valid authentication broken after enabling lockout' >&2; exit 1; }
expect_rejected "$u" wrong
auth "$u" correct
expect_rejected "$u" wrong
expect_rejected "$u" wrong
expect_rejected "$u" correct
perl -MVyatta::Login::Faillock=tally_counts -e 'my %counts = tally_counts(); die "wrong tally count\n" unless $counts{$ARGV[0]} == 2' "$u"
# Root remains available, and the recovery RPC clears the local user's record.
expect_rejected root wrong
expect_rejected root wrong
auth root correct
printf '{"user":"%s"}' "$u" | perl "$repo/scripts/system/vyatta_tally_rpc" --action=reset
auth "$u" correct
# Deactivation returns the local stack to stock authentication.
expect_rejected "$u" wrong
expect_rejected "$u" wrong
unset TEST_ENABLE_LOCKOUT
update
auth "$u" correct
