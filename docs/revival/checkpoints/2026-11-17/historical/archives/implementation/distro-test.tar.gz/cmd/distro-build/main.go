// Command distro-build builds the NuDanOS package set.
package main

import (
	"context"
	"flag"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"text/tabwriter"
	"time"

	"github.com/nudanos/distro/internal/aptmirror"
	"github.com/nudanos/distro/internal/aptrepo"
	"github.com/nudanos/distro/internal/build"
	"github.com/nudanos/distro/internal/control"
	"github.com/nudanos/distro/internal/engine"
	"github.com/nudanos/distro/internal/fetch"
	"github.com/nudanos/distro/internal/imagebuild"
	"github.com/nudanos/distro/internal/installtest"
	"github.com/nudanos/distro/internal/lint"
	"github.com/nudanos/distro/internal/manifest"
	"github.com/nudanos/distro/internal/plan"
	"github.com/nudanos/distro/internal/updates"
	"github.com/nudanos/distro/internal/upstream"
	"github.com/nudanos/distro/internal/workspace"
)

type localFlags map[string]string

func (l localFlags) String() string {
	var s []string
	for k, v := range l {
		s = append(s, k+"="+v)
	}
	sort.Strings(s)
	return strings.Join(s, ",")
}

func (l localFlags) Set(v string) error {
	name, dir, ok := strings.Cut(v, "=")
	if !ok || name == "" || dir == "" {
		return fmt.Errorf("want name=dir, got %q", v)
	}
	abs, err := filepath.Abs(dir)
	if err != nil {
		return err
	}
	l[name] = abs
	return nil
}

// builderLabel records the hash of builder/ an image was built from.
const builderLabel = "org.nudanos.builder-hash"

// checkBuilder fails when the image was not built from the current builder/.
func checkBuilder(image, label, want string) error {
	if label != want {
		return fmt.Errorf("builder image %s is out of date with builder/ (image %q, directory %q); "+
			"run 'distro-build builder' first", image, label, want)
	}
	return nil
}

type app struct {
	manifest, work, image, builderDir, gnupg, key string
	eng                                           engine.Engine
	local                                         localFlags
	jobs                                          int
	firmware                                      string
	smoke                                         bool
	referenceISO                                  string
	capture                                       bool
	initBaseline, updateBaseline                  bool
}

func (a *app) outRoot() string { return filepath.Join(a.work, "out") }

func (a *app) checkWork() error {
	ok, err := workspace.CaseSensitive(a.work)
	if err != nil {
		return err
	}
	if !ok {
		return fmt.Errorf("work directory %s is on a case-insensitive filesystem; DANOS sources contain "+
			"names that differ only by case. Use a case-sensitive volume (see docs/workspace.md)", a.work)
	}
	return nil
}

// fetch mirrors every ready apt entry, then checks out every ready danos entry
// (or uses its -local override) and returns the source directory for each.
// With tolerate, an entry that cannot be fetched or prepared is recorded in
// failed instead of ending the run; its previous checkout, if any, stays in
// dirs for planning only (the caller must not build anything that needs it).
func (a *app) fetch(ctx context.Context, m *manifest.Manifest, tolerate bool) (map[string]string, map[string]error, error) {
	if err := a.checkWork(); err != nil {
		return nil, nil, err
	}
	if err := build.Prune(a.outRoot(), readyNames(m), os.Stderr); err != nil {
		return nil, nil, err
	}
	if len(m.Ready(manifest.Apt)) > 0 {
		if _, err := a.builderSalt(ctx); err != nil {
			return nil, nil, err
		}
	}
	if err := a.mirror(ctx, m); err != nil {
		return nil, nil, err
	}
	dirs := map[string]string{}
	failed := map[string]error{}
	// keep records a failed entry, keeping a previous checkout for planning.
	keep := func(name, d string, err error) error {
		if !tolerate {
			return err
		}
		fmt.Fprintf(os.Stderr, "==> %s could not be fetched; builds that need it will stop: %v\n", name, err)
		failed[name] = err
		if _, serr := os.Stat(filepath.Join(d, "debian", "control")); serr == nil {
			dirs[name] = d
		}
		return nil
	}
	for _, e := range m.Ready(manifest.Danos) {
		if d, ok := a.local[e.Name]; ok {
			dirs[e.Name] = d
			continue
		}
		d := filepath.Join(a.work, "src", e.Name)
		fmt.Fprintf(os.Stderr, "==> fetch %s@%s\n", e.Name, e.Ref)
		if err := fetch.Git(ctx, e.Repo, e.Ref, d, os.Stderr); err != nil {
			if err := keep(e.Name, d, err); err != nil {
				return nil, nil, err
			}
			continue
		}
		dirs[e.Name] = d
	}
	for _, e := range m.Ready(manifest.Upstream) {
		fmt.Fprintf(os.Stderr, "==> prepare %s %s (%s)\n", e.Name, e.Version, e.Tag)
		d, err := upstream.Prepare(ctx, e, filepath.Join(filepath.Dir(a.manifest), "patches"), a.work, os.Stderr)
		if err != nil {
			if err := keep(e.Name, filepath.Join(a.work, "src", e.Name), err); err != nil {
				return nil, nil, err
			}
			continue
		}
		dirs[e.Name] = d
	}

	for name := range a.local {
		if _, ok := dirs[name]; !ok {
			return nil, nil, fmt.Errorf("-local %s: no ready danos entry with that name", name)
		}
	}
	return dirs, failed, nil
}

// readyNames is every entry whose output belongs in the pool.
func readyNames(m *manifest.Manifest) map[string]bool {
	keep := map[string]bool{}
	for _, k := range []manifest.Kind{manifest.Danos, manifest.Apt, manifest.Upstream} {
		for _, e := range m.Ready(k) {
			keep[e.Name] = true
		}
	}
	return keep
}

func graph(dirs map[string]string) (*plan.Graph, [][]string, error) {
	srcs := map[string]*control.Source{}
	for name, d := range dirs {
		s, err := control.ReadSource(filepath.Join(d, "debian", "control"))
		if err != nil {
			return nil, nil, err
		}
		srcs[name] = s
	}
	g, err := plan.Build(srcs)
	if err != nil {
		return nil, nil, err
	}
	// build-package lints with the profile once it is in the pool.
	g.AddImplicitDep(lintProfile)
	tiers, err := g.Tiers()
	return g, tiers, err
}

// lintProfile is the lintian profile build-package lints every package with.
const lintProfile = "lintian-profile-vyatta"

// packageLog opens work/logs/<name>.log (truncated) for one package's build.
// With lintFlags (an in-scope port, built with -Wall -Wextra) the log starts
// with lint.FlagsMarker, so lint can tell it from a log that predates them.
func packageLog(work, name string, lintFlags bool) (io.WriteCloser, error) {
	dir := filepath.Join(work, "logs")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return nil, err
	}
	f, err := os.Create(filepath.Join(dir, name+".log"))
	if err != nil || !lintFlags {
		return f, err
	}
	if _, err := fmt.Fprintln(f, lint.FlagsMarker); err != nil {
		f.Close()
		return nil, err
	}
	return f, nil
}

// buildEnv is the environment for one package build.
// lintFlags adds the code-quality compiler warnings (spec 2026-10-14 §3)
// for an in-scope port.
func buildEnv(name string, uid, gid, jobs int, profiles []string, lintFlags bool) map[string]string {
	env := map[string]string{"PKG": name, "HOST_UID": strconv.Itoa(uid), "HOST_GID": strconv.Itoa(gid),
		"JOBS": strconv.Itoa(jobs)}
	if len(profiles) > 0 {
		env["DEB_BUILD_PROFILES"] = strings.Join(profiles, " ")
	}
	if lintFlags {
		env["DEB_CFLAGS_MAINT_APPEND"] = warningFlags
		env["DEB_CXXFLAGS_MAINT_APPEND"] = warningFlags
	}
	return env
}

// warningFlags are added to the compiler flags of in-scope ports. -Wno-error
// comes last so a port's own -Werror does not turn the added warnings into
// build failures: lint counts them from the log instead.
const warningFlags = "-Wall -Wextra -Wno-error"

// inScope lists the ports the code-quality work covers (spec 2026-10-14 §1):
// ready danos entries of milestone 1.0, sorted.
func inScope(m *manifest.Manifest) []string {
	var out []string
	for _, e := range m.Packages {
		if e.Kind == manifest.Danos && e.Milestone == "1.0" && e.Ready {
			out = append(out, e.Name)
		}
	}
	sort.Strings(out)
	return out
}

func (a *app) containerBuild(m *manifest.Manifest) build.Func {
	scope := map[string]bool{}
	for _, n := range inScope(m) {
		scope[n] = true
	}
	profiles := map[string][]string{}
	for _, e := range m.Packages {
		if len(e.Profiles) > 0 {
			profiles[e.Name] = e.Profiles
		}
	}
	return func(ctx context.Context, name, src, outDir string) error {
		u, g := a.eng.OwnerIDs(os.Getuid(), os.Getgid())
		lf, err := packageLog(a.work, name, scope[name])
		if err != nil {
			return err
		}
		defer lf.Close()
		out := io.MultiWriter(os.Stderr, lf)
		return a.eng.Run(ctx, engine.RunSpec{
			Image: a.image,
			Mounts: []engine.Mount{
				{Host: src, Container: "/src", ReadOnly: true},
				{Host: a.outRoot(), Container: "/pool", ReadOnly: true},
				{Host: outDir, Container: "/out"},
			},
			Env: buildEnv(name, u, g, max(1, runtime.NumCPU()/max(1, a.jobs)), profiles[name], scope[name]),
			Cmd: []string{"/usr/local/bin/build-package"},
		}, out, out)
	}
}

// builderSalt returns the builder hash after checking the image matches builder/.
func (a *app) builderSalt(ctx context.Context) (string, error) {
	want, err := build.TreeHash(a.builderDir)
	if err != nil {
		return "", fmt.Errorf("hashing builder dir: %w", err)
	}
	label, err := a.eng.ImageLabel(ctx, a.image, builderLabel)
	if err != nil {
		return "", err
	}
	return want, checkBuilder(a.image, label, want)
}

func (a *app) run(ctx context.Context, cmd string, names []string) error {
	switch cmd {
	case "builder":
		hash, err := build.TreeHash(a.builderDir)
		if err != nil {
			return fmt.Errorf("hashing builder dir: %w", err)
		}
		return a.eng.BuildImage(ctx, a.builderDir, a.image, map[string]string{builderLabel: hash}, os.Stderr, os.Stderr)
	case "fetch", "plan", "build":
	case "repo":
		return a.repo(ctx)
	case "check-updates":
		return a.checkUpdates(ctx)
	case "image":
		return a.buildImage(ctx)
	case "lint":
		return a.lintCmd(ctx, names)
	case "test":
		return a.test(ctx, names)
	default:
		return fmt.Errorf("unknown command %q", cmd)
	}
	m, err := manifest.Load(a.manifest)
	if err != nil {
		return err
	}
	// Only a build of named packages tolerates fetch failures: a full build
	// (or fetch) needs every entry.
	dirs, fetchFailed, err := a.fetch(ctx, m, len(names) > 0 && cmd != "fetch")
	if err != nil || cmd == "fetch" {
		return err
	}
	g, tiers, err := graph(dirs)
	if err != nil {
		return err
	}
	if len(names) > 0 {
		for _, n := range names {
			if err, ok := fetchFailed[n]; ok {
				return fmt.Errorf("%s could not be fetched: %w", n, err)
			}
		}
		keep, err := g.Closure(names)
		if err != nil {
			return err
		}
		if err := fetchBlocks(keep, fetchFailed); err != nil {
			return err
		}
		tiers = plan.Filter(tiers, keep)
	}
	if cmd == "plan" {
		for i, t := range tiers {
			fmt.Printf("tier %d (%d): %s\n", i, len(t), strings.Join(t, " "))
		}
		return nil
	}
	salt, err := a.builderSalt(ctx)
	if err != nil {
		return err
	}
	b := &build.Builder{SrcDirs: dirs, OutRoot: a.outRoot(), StateFile: filepath.Join(a.work, "state.json"),
		KeySalt: a.image + ":" + salt, KeyExtra: keyExtras(m), Build: a.containerBuild(m), Log: os.Stderr, Workers: a.jobs, BeforeTier: a.indexPool}
	results, err := b.Run(ctx, tiers, g.Deps)
	if err != nil {
		return err
	}
	tw := tabwriter.NewWriter(os.Stdout, 0, 4, 2, ' ', 0)
	failed := 0
	for _, r := range results {
		fmt.Fprintf(tw, "%s\t%s\t%s\n", r.Name, r.Status, r.Detail)
		if r.Status == build.Failed || r.Status == build.Skipped {
			failed++
		}
	}
	tw.Flush()
	if failed > 0 {
		return fmt.Errorf("%d of %d packages failed or were skipped", failed, len(results))
	}
	return nil
}

// buildImage builds the ISO from work/repo. Its version and timestamp come from
// the distro commit, so the same commit builds the same image name.
func (a *app) buildImage(ctx context.Context) error {
	repo := filepath.Join(a.work, "repo")
	if _, err := os.Stat(filepath.Join(repo, "dists", "trixie", "InRelease")); err != nil {
		return fmt.Errorf("image: no signed repo in %s; run 'distro-build repo' first", repo)
	}
	if _, err := a.builderSalt(ctx); err != nil {
		return err
	}
	dir := filepath.Dir(a.manifest)
	out, err := exec.CommandContext(ctx, "git", "-C", dir, "log", "-1", "--format=%ct").Output()
	if err != nil {
		return fmt.Errorf("image: reading the commit time: %w", err)
	}
	epoch := strings.TrimSpace(string(out))
	sec, err := strconv.ParseInt(epoch, 10, 64)
	if err != nil {
		return fmt.Errorf("image: commit time %q: %w", epoch, err)
	}
	version := "1.0~" + time.Unix(sec, 0).UTC().Format("20060102")
	config, err := filepath.Abs(filepath.Join(dir, "image"))
	if err != nil {
		return err
	}
	outDir := filepath.Join(a.work, "image")
	if err := os.MkdirAll(outDir, 0o755); err != nil {
		return err
	}
	uid, gid := a.eng.OwnerIDs(os.Getuid(), os.Getgid())
	return a.eng.Run(ctx, imagebuild.Spec(a.image, repo, config, outDir, version, epoch, uid, gid), os.Stderr, os.Stderr)
}

// test runs the image test layers: "install" (layer 2) and "boot" (layer 3).
func (a *app) test(ctx context.Context, args []string) error {
	if len(args) < 1 {
		return fmt.Errorf("usage: distro-build test install|boot|scenario <name>|scenarios|fixtures")
	}
	switch args[0] {
	case "scenario":
		if len(args) != 2 {
			return fmt.Errorf("usage: distro-build test scenario <name>")
		}
		return a.testScenarios(ctx, args[1:], false)
	case "scenarios":
		return a.testScenarios(ctx, nil, true)
	case "fixtures":
		return a.testFixtures(ctx)
	}
	repo := filepath.Join(a.work, "repo")
	if _, err := os.Stat(filepath.Join(repo, "dists", "trixie", "InRelease")); err != nil {
		return fmt.Errorf("test: no signed repo in %s; run 'distro-build repo' first", repo)
	}
	switch args[0] {
	case "install":
		tests, err := filepath.Abs(filepath.Join(filepath.Dir(a.manifest), "tests", "integration"))
		if err != nil {
			return err
		}
		return a.eng.Run(ctx, installtest.Spec(repo, tests), os.Stdout, os.Stderr)
	case "boot":
		return a.testBoot(ctx)
	}
	return fmt.Errorf("unknown test %q (want install, boot, scenario, scenarios or fixtures)", args[0])
}

// scenarioRun is one invocation of the scenario runner (layer 4).
type scenarioRun struct {
	ISO, Tests, Work        string
	Reference, Capture, KVM bool
	Names                   []string
	All                     bool
	Fixtures                bool
}

// scenarioSpec is the tester container that runs cmd/scenario: the ISO's
// directory at /iso, distro's tests/ at /tests (writable only to capture
// 2105 references), and the scratch directory, holding the runner, at /work.
func scenarioSpec(r scenarioRun) (engine.RunSpec, error) {
	if r.Capture && !r.Reference {
		return engine.RunSpec{}, fmt.Errorf("-capture writes 2105 references and needs -reference-iso")
	}
	cmd := []string{"/work/scenario", "-iso", "/iso/" + filepath.Base(r.ISO), "-tests", "/tests", "-work", "/work"}
	if r.Reference {
		cmd = append(cmd, "-reference")
	}
	if r.Capture {
		cmd = append(cmd, "-capture")
	}
	if r.KVM {
		cmd = append(cmd, "-kvm")
	}
	if r.All {
		cmd = append(cmd, "-all")
	}
	if r.Fixtures {
		cmd = append(cmd, "-fixtures")
	}
	for _, n := range r.Names {
		cmd = append(cmd, "-scenario", n)
	}
	spec := engine.RunSpec{Image: "nudanos/tester:trixie",
		Mounts: []engine.Mount{
			{Host: filepath.Dir(r.ISO), Container: "/iso", ReadOnly: true},
			{Host: r.Tests, Container: "/tests", ReadOnly: !r.Capture},
			{Host: r.Work, Container: "/work"},
		},
		Cmd: cmd}
	if r.KVM {
		spec.Devices = []string{"/dev/kvm"}
	}
	return spec, nil
}

// testScenarios cross-compiles cmd/scenario and runs it in the tester
// container on the newest NuDanOS ISO, or on -reference-iso.
func (a *app) testScenarios(ctx context.Context, names []string, all bool) error {
	return a.runScenarioContainer(ctx, scenarioRun{Names: names, All: all})
}

// testFixtures loads every captured 2105 configuration on one NuDanOS
// router, then boots one with a DPDK-only setting (plan 4).
func (a *app) testFixtures(ctx context.Context) error {
	if a.referenceISO != "" {
		return fmt.Errorf("test fixtures runs on NuDanOS; drop -reference-iso")
	}
	return a.runScenarioContainer(ctx, scenarioRun{Fixtures: true})
}

// runScenarioContainer cross-compiles cmd/scenario and runs it in the tester
// container on the newest NuDanOS ISO, or on -reference-iso.
func (a *app) runScenarioContainer(ctx context.Context, r scenarioRun) error {
	iso := a.referenceISO
	if iso == "" {
		isos, _ := filepath.Glob(filepath.Join(a.work, "image", "nudanos-*-amd64.iso"))
		if len(isos) == 0 {
			return fmt.Errorf("test scenario: no ISO in %s; run 'distro-build image' first", filepath.Join(a.work, "image"))
		}
		sort.Strings(isos)
		iso = isos[len(isos)-1]
	}
	iso, err := filepath.Abs(iso)
	if err != nil {
		return err
	}
	dir := filepath.Dir(a.manifest)
	tests, err := filepath.Abs(filepath.Join(dir, "tests"))
	if err != nil {
		return err
	}
	work := filepath.Join(a.work, "scenarios")
	if err := os.MkdirAll(work, 0o755); err != nil {
		return err
	}
	build := exec.CommandContext(ctx, "go", "build", "-o", filepath.Join(work, "scenario"), "./cmd/scenario")
	build.Dir, build.Env = dir, append(os.Environ(), "CGO_ENABLED=0", "GOOS=linux", "GOARCH=amd64")
	build.Stdout, build.Stderr = os.Stderr, os.Stderr
	if err := build.Run(); err != nil {
		return fmt.Errorf("test scenario: building the runner: %w", err)
	}
	if err := a.eng.BuildImage(ctx, filepath.Join(dir, "tester"), "nudanos/tester:trixie", nil, os.Stderr, os.Stderr); err != nil {
		return err
	}
	_, kvmErr := os.Stat("/dev/kvm")
	r.ISO, r.Tests, r.Work, r.Reference, r.Capture, r.KVM = iso, tests, work, a.referenceISO != "", a.capture, kvmErr == nil
	spec, err := scenarioSpec(r)
	if err != nil {
		return err
	}
	err = a.eng.Run(ctx, spec, os.Stdout, os.Stderr)
	fmt.Fprintf(os.Stderr, "transcripts: %s\n", work)
	return err
}

// testBoot cross-compiles cmd/boottest, builds the tester image and boots the
// newest ISO in work/image under QEMU (KVM when /dev/kvm exists).
func (a *app) testBoot(ctx context.Context) error {
	isos, _ := filepath.Glob(filepath.Join(a.work, "image", "nudanos-*-amd64.iso"))
	if len(isos) == 0 {
		return fmt.Errorf("test boot: no ISO in %s; run 'distro-build image' first", filepath.Join(a.work, "image"))
	}
	sort.Strings(isos)
	iso := isos[len(isos)-1]
	dir := filepath.Dir(a.manifest)
	bt := filepath.Join(a.work, "boottest")
	if err := os.MkdirAll(bt, 0o755); err != nil {
		return err
	}
	build := exec.CommandContext(ctx, "go", "build", "-o", filepath.Join(bt, "boottest"), "./cmd/boottest")
	build.Dir, build.Env = dir, append(os.Environ(), "CGO_ENABLED=0", "GOOS=linux", "GOARCH=amd64")
	build.Stdout, build.Stderr = os.Stderr, os.Stderr
	if err := build.Run(); err != nil {
		return fmt.Errorf("test boot: building boottest: %w", err)
	}
	if err := a.eng.BuildImage(ctx, filepath.Join(dir, "tester"), "nudanos/tester:trixie", nil, os.Stderr, os.Stderr); err != nil {
		return err
	}
	spec := engine.RunSpec{Image: "nudanos/tester:trixie",
		Mounts: []engine.Mount{
			{Host: filepath.Dir(iso), Container: "/iso", ReadOnly: true},
			{Host: bt, Container: "/work"},
		},
		Cmd: []string{"/work/boottest", "-iso", "/iso/" + filepath.Base(iso), "-firmware", a.firmware}}
	if a.smoke {
		spec.Cmd = append(spec.Cmd, "-smoke")
	}
	if _, err := os.Stat("/dev/kvm"); err == nil {
		spec.Devices = []string{"/dev/kvm"}
		spec.Cmd = append(spec.Cmd, "-kvm")
	}
	err := a.eng.Run(ctx, spec, os.Stdout, os.Stderr)
	fmt.Fprintf(os.Stderr, "serial transcript: %s\n", filepath.Join(bt, "serial.log"))
	return err
}

func (a *app) mirror(ctx context.Context, m *manifest.Manifest) error {
	for _, e := range m.Ready(manifest.Apt) {
		cached, err := aptmirror.Mirror(ctx, a.eng, a.image, e, a.outRoot(),
			filepath.Join(a.work, "mirror-state.json"), os.Stderr)
		if err != nil {
			return err
		}
		status := "downloaded"
		if cached {
			status = "cached"
		}
		fmt.Fprintf(os.Stderr, "==> mirror %s %s\n", e.Name, status)
	}
	return nil
}

func (a *app) repo(ctx context.Context) error {
	if a.key == "" {
		return fmt.Errorf("repo: -key <fingerprint> is required")
	}
	if err := a.checkWork(); err != nil {
		return err
	}
	m, err := manifest.Load(a.manifest)
	if err != nil {
		return err
	}
	if err := build.Prune(a.outRoot(), readyNames(m), os.Stderr); err != nil {
		return err
	}
	if _, err := a.builderSalt(ctx); err != nil {
		return err
	}
	dir := filepath.Join(a.work, "repo")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return err
	}
	uid, gid := a.eng.OwnerIDs(os.Getuid(), os.Getgid())
	return a.eng.Run(ctx, aptrepo.Spec(a.image, a.outRoot(), dir, a.gnupg, a.key, uid, gid),
		os.Stderr, os.Stderr)
}

func main() {
	home, _ := os.UserHomeDir()
	a := &app{local: localFlags{}}
	flag.StringVar(&a.manifest, "manifest", "manifest.yaml", "path to manifest.yaml")
	flag.StringVar(&a.work, "work", "work", "work directory (must be case-sensitive)")
	engineBin := flag.String("engine", "docker", "container engine: docker or podman")
	flag.StringVar(&a.image, "image", "nudanos/builder:trixie", "builder image tag")
	flag.StringVar(&a.builderDir, "builder-dir", "builder", "directory holding the builder Dockerfile")
	flag.StringVar(&a.gnupg, "gnupg", filepath.Join(home, ".nudanos", "gnupg"), "GnuPG home with the archive signing key (repo)")
	flag.StringVar(&a.key, "key", "", "archive signing key fingerprint (repo)")
	flag.IntVar(&a.jobs, "jobs", 1, "packages built at once within a tier")
	flag.StringVar(&a.firmware, "firmware", "bios", "test boot: bios or efi")
	flag.BoolVar(&a.smoke, "smoke", false, "test boot: only boot to the login prompt")
	flag.StringVar(&a.referenceISO, "reference-iso", "", "test scenario(s): run on this DANOS 2105 ISO instead of the NuDanOS one")
	flag.BoolVar(&a.capture, "capture", false, "test scenario(s): write the 2105 references (needs -reference-iso)")
	flag.Var(a.local, "local", "use a local checkout for a ready danos entry: name=dir (repeatable)")
	flag.BoolVar(&a.initBaseline, "init-baseline", false, "lint: write lint-baseline.json from today's counts (refuses if it exists)")
	flag.BoolVar(&a.updateBaseline, "update-baseline", false, "lint: lower the linted ports in lint-baseline.json to their counts")
	flag.Usage = func() {
		fmt.Fprintf(os.Stderr, "usage: distro-build [flags] builder|fetch|plan|build|repo|image|lint|test install|boot|scenario <name>|scenarios|fixtures|check-updates [name…]\n")
		flag.PrintDefaults()
	}
	flag.Parse()
	if flag.NArg() < 1 {
		flag.Usage()
		os.Exit(2)
	}
	if *engineBin != "docker" && *engineBin != "podman" {
		fmt.Fprintln(os.Stderr, "error: -engine must be docker or podman")
		os.Exit(2)
	}
	a.eng = engine.Engine{Bin: *engineBin}
	abs, err := filepath.Abs(a.work)
	if err == nil {
		a.work = abs
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	defer stop()
	if err := a.run(ctx, flag.Arg(0), flag.Args()[1:]); err != nil {
		fmt.Fprintln(os.Stderr, "error:", err)
		os.Exit(1)
	}
}

// indexPool writes the pool's apt index once, before a tier's builds start.
func (a *app) indexPool(ctx context.Context) error {
	if err := os.MkdirAll(a.outRoot(), 0o755); err != nil {
		return err
	}
	return a.eng.Run(ctx, engine.RunSpec{
		Image:   a.image,
		Mounts:  []engine.Mount{{Host: a.outRoot(), Container: "/pool"}},
		Network: "none",
		Cmd:     []string{"/usr/local/bin/index-pool"},
	}, os.Stderr, os.Stderr)
}

func remoteTags(ctx context.Context, repo string) ([]string, error) {
	out, err := exec.CommandContext(ctx, "git", "ls-remote", "--tags", "--refs", repo).Output()
	if err != nil {
		return nil, fmt.Errorf("git ls-remote %s: %w", repo, err)
	}
	var tags []string
	for _, line := range strings.Split(string(out), "\n") {
		if _, ref, ok := strings.Cut(line, "\trefs/tags/"); ok {
			tags = append(tags, ref)
		}
	}
	return tags, nil
}

// remoteHead is the commit branch points at in repo.
func remoteHead(ctx context.Context, repo, branch string) (string, error) {
	out, err := exec.CommandContext(ctx, "git", "ls-remote", "--heads", "--", repo, "refs/heads/"+branch).Output()
	if err != nil {
		return "", fmt.Errorf("git ls-remote %s: %w", repo, err)
	}
	head, _, ok := strings.Cut(strings.TrimSpace(string(out)), "\t")
	if !ok {
		return "", fmt.Errorf("%s: no branch %q", repo, branch)
	}
	return head, nil
}

// checkUpdates reports pinned versions that upstream has superseded.
func (a *app) checkUpdates(ctx context.Context) error {
	m, err := manifest.Load(a.manifest)
	if err != nil {
		return err
	}
	var drift []updates.Drift
	for _, e := range m.Packages {
		if e.Kind != manifest.Upstream || e.TagPattern == "" || e.Version == "" {
			continue
		}
		tags, err := remoteTags(ctx, e.Upstream)
		if err != nil {
			return err
		}
		d, err := updates.CheckUpstream(e, tags)
		if err != nil {
			return err
		}
		if d != nil {
			drift = append(drift, *d)
		}
		if e.PackagingBranch != "" {
			head, err := remoteHead(ctx, e.Packaging, e.PackagingBranch)
			if err != nil {
				return err
			}
			if d := updates.CheckPackaging(e, head); d != nil {
				drift = append(drift, *d)
			}
		}
	}
	client := &http.Client{Timeout: 60 * time.Second}
	for _, e := range m.Packages {
		if e.Kind != manifest.Apt {
			continue
		}
		ds, err := updates.CheckApt(ctx, e, client)
		if err != nil {
			return err
		}
		drift = append(drift, ds...)
	}
	drift, held := updates.SplitHeld(drift)
	for _, d := range held {
		fmt.Printf("held: %s %s (newest %s): %s\n", d.Name, d.Current, d.Latest, d.Held)
	}
	if len(drift) == 0 {
		fmt.Println("all pinned versions are current")
		return nil
	}
	tw := tabwriter.NewWriter(os.Stdout, 0, 4, 2, ' ', 0)
	fmt.Fprintln(tw, "PACKAGE\tPINNED\tLATEST\tWHERE")
	for _, d := range drift {
		fmt.Fprintf(tw, "%s\t%s\t%s\t%s\n", d.Name, d.Current, d.Latest, d.Detail)
	}
	tw.Flush()
	return fmt.Errorf("%d pinned versions have newer releases", len(drift))
}

// keyExtras are the per-package build inputs that live in the manifest rather
// than the source tree; they join each package's cache key.
func keyExtras(m *manifest.Manifest) map[string]string {
	out := map[string]string{}
	for _, e := range m.Packages {
		if len(e.Profiles) > 0 {
			p := append([]string(nil), e.Profiles...)
			sort.Strings(p)
			out[e.Name] = "profiles=" + strings.Join(p, ",")
		}
	}
	for _, n := range inScope(m) {
		if out[n] != "" {
			out[n] += ";"
		}
		out[n] += "flags=wall-wextra-noerror"
	}
	return out
}

// fetchBlocks reports the entries in the build closure keep that could not be
// fetched.
func fetchBlocks(keep map[string]bool, failed map[string]error) error {
	var msgs []string
	for name, err := range failed {
		if keep[name] {
			msgs = append(msgs, fmt.Sprintf("%s: %v", name, err))
		}
	}
	if len(msgs) == 0 {
		return nil
	}
	sort.Strings(msgs)
	return fmt.Errorf("the build needs entries that could not be fetched:\n  %s", strings.Join(msgs, "\n  "))
}
