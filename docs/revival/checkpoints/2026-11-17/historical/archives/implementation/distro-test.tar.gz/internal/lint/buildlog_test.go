package lint

import (
	"reflect"
	"strings"
	"testing"
)

const flagsLine = "nudanos-lint-flags: wall-wextra\n"

var cOnly = map[string]bool{"c": true}

func TestFromBuildLogWarnings(t *testing.T) {
	log := flagsLine +
		"gcc -Wall -Wextra -c src/vci.c\n" +
		"src/vci.c:42:9: warning: unused variable 'n' [-Wunused-variable]\n" +
		"/build/pkg/src/vci.c:42:9: warning: unused variable 'n' [-Wunused-variable]\n" + // the same one, absolute
		"/usr/include/x86_64-linux-gnu/bits/stdio2.h:3:1: warning: ignoring return value [-Wunused-result]\n" +
		"lib/x.cc:7:3: warning: comparison of integer expressions of different signedness [-Wsign-compare]\n"
	got, err := FromBuildLog("libvci", cOnly, []byte(log))
	if err != nil {
		t.Fatal(err)
	}
	want := []Finding{
		{Port: "libvci", Tool: "cc", File: "src/vci.c", Line: 42, Rule: "-Wunused-variable", Message: "unused variable 'n'"},
		{Port: "libvci", Tool: "cc", File: "lib/x.cc", Line: 7, Rule: "-Wsign-compare", Message: "comparison of integer expressions of different signedness"},
	}
	if !reflect.DeepEqual(got, want) {
		t.Errorf("got  %+v\nwant %+v", got, want)
	}
}

// A warning for a file compiled from a subdirectory (cpputest/ building
// ../src/client/x.c) names it relative to that directory; make's
// "Entering directory" lines say which, so it is the same src/ file as
// the warning from the top-level build.
func TestFromBuildLogWarningsInSubdirectories(t *testing.T) {
	log := flagsLine +
		"make[1]: Entering directory '/build/pkg'\n" +
		"src/client/x.c:40:36: warning: comparison of integer expressions of different signedness [-Wsign-compare]\n" +
		"make[2]: Entering directory '/build/pkg/cpputest'\n" +
		"../src/client/x.c:40:36: warning: comparison of integer expressions of different signedness [-Wsign-compare]\n" +
		"mocks.c:3:1: warning: unused parameter 'a' [-Wunused-parameter]\n" +
		"make[2]: Leaving directory '/build/pkg/cpputest'\n" +
		"src/y.c:9:1: warning: unused parameter 'b' [-Wunused-parameter]\n" +
		"make[1]: Leaving directory '/build/pkg'\n"
	got, err := FromBuildLog("vyatta-cfg", cOnly, []byte(log))
	if err != nil {
		t.Fatal(err)
	}
	want := []Finding{
		{Port: "vyatta-cfg", Tool: "cc", File: "src/client/x.c", Line: 40, Rule: "-Wsign-compare", Message: "comparison of integer expressions of different signedness"},
		{Port: "vyatta-cfg", Tool: "cc", File: "cpputest/mocks.c", Line: 3, Rule: "-Wunused-parameter", Message: "unused parameter 'a'"},
		{Port: "vyatta-cfg", Tool: "cc", File: "src/y.c", Line: 9, Rule: "-Wunused-parameter", Message: "unused parameter 'b'"},
	}
	if !reflect.DeepEqual(got, want) {
		t.Errorf("got  %+v\nwant %+v", got, want)
	}
}

func TestFromBuildLogStaticcheck(t *testing.T) {
	log := "nudanos-staticcheck: services/x.go:12:2: this value of err is never used (SA4006)\n" +
		"nudanos-staticcheck: done\n"
	got, err := FromBuildLog("vci", map[string]bool{"go": true}, []byte(log))
	if err != nil {
		t.Fatal(err)
	}
	want := []Finding{{Port: "vci", Tool: "staticcheck", File: "services/x.go", Line: 12, Rule: "SA4006", Message: "this value of err is never used"}}
	if !reflect.DeepEqual(got, want) {
		t.Errorf("got  %+v\nwant %+v", got, want)
	}
}

// staticcheck follows some findings with indented "related information"
// lines (S1034's other type assertions): part of the finding above, not a
// failed run, and not findings of their own.
func TestFromBuildLogStaticcheckRelatedInformation(t *testing.T) {
	log := "nudanos-staticcheck: mgmterrorlist.go:26:9: assigning the result of this type assertion to a variable could eliminate type assertions in switch cases (S1034)\n" +
		"nudanos-staticcheck: \tmgmterrorlist.go:30:12: could eliminate this type assertion\n" +
		"nudanos-staticcheck: done\n"
	got, err := FromBuildLog("mgmterror", map[string]bool{"go": true}, []byte(log))
	if err != nil {
		t.Fatal(err)
	}
	want := []Finding{{Port: "mgmterror", Tool: "staticcheck", File: "mgmterrorlist.go", Line: 26, Rule: "S1034",
		Message: "assigning the result of this type assertion to a variable could eliminate type assertions in switch cases"}}
	if !reflect.DeepEqual(got, want) {
		t.Errorf("got  %+v\nwant %+v", got, want)
	}
}

// A cached package's log can predate the flags: that is not "no warnings"
// (Review Focus 5).
func TestFromBuildLogStaleIsAnError(t *testing.T) {
	_, err := FromBuildLog("libvci", cOnly, []byte("gcc -c src/vci.c\n"))
	if err == nil || !strings.Contains(err.Error(), "rebuild libvci") {
		t.Errorf("err = %v", err)
	}
}

func TestFromBuildLogGoWithoutStaticcheckIsAFinding(t *testing.T) {
	got, err := FromBuildLog("vci", map[string]bool{"go": true}, []byte("go vet ./...\n"))
	if err != nil {
		t.Fatal(err)
	}
	if len(got) != 1 || got[0].Tool != "lint" || got[0].Rule != "staticcheck-not-run" {
		t.Errorf("got %+v", got)
	}
}

// A port with neither C nor Go needs nothing from its log.
func TestFromBuildLogPerlOnlyNeedsNoLog(t *testing.T) {
	got, err := FromBuildLog("vyatta-op", map[string]bool{"perl": true}, nil)
	if err != nil || len(got) != 0 {
		t.Errorf("got %v, %v", got, err)
	}
}

// A staticcheck that could not run or load the packages prints something
// other than findings before the "done" marker: that port was not checked
// (Review Focus 2), even though the marker is there.
func TestFromBuildLogStaticcheckFailureIsAnError(t *testing.T) {
	for _, line := range []string{
		"nudanos-staticcheck: /bin/sh: 1: staticcheck: not found",
		"nudanos-staticcheck: -: could not load package github.com/x/y: no Go files",
	} {
		_, err := FromBuildLog("vci", map[string]bool{"go": true}, []byte(line+"\nnudanos-staticcheck: done\n"))
		if err == nil || !strings.Contains(err.Error(), "vci") {
			t.Errorf("%q: err = %v", line, err)
		}
	}
}
