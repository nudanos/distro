package fixtures

import (
	"bytes"
	"context"
	"crypto/md5"
	"encoding/base64"
	"fmt"
	"io"
	"net"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/nudanos/distro/internal/boottest"
	"github.com/nudanos/distro/internal/topology"
)

func identity(d time.Duration) time.Duration { return d }

const paths = "# comment\nsecurity firewall\ninterfaces dataplane * speed !auto\n"

// fakeRouter answers like a NuDanOS console: a base64 heredoc lands in a
// file whose md5sum it reports, configure/load/commit/exit, the path list,
// and "show configuration commands" from show.
func fakeRouter(t *testing.T, show string) *topology.VM {
	t.Helper()
	return fakeRouterPaths(t, show, paths)
}

var (
	mu   sync.Mutex
	seen []string // lines the fake router received
)

func fakeRouterPaths(t *testing.T, show, paths string) *topology.VM {
	return fakeRouterHook(t, show, paths, 0)
}

func fakeRouterHook(t *testing.T, show, paths string, hookStatus int) *topology.VM {
	t.Helper()
	mu.Lock()
	seen = nil
	mu.Unlock()
	a, b := net.Pipe()
	t.Cleanup(func() { a.Close(); b.Close() })
	go func() {
		op, cfg := "\r\nvyatta@r1:~$ ", "\r\n[edit]\r\nvyatta@r1# "
		var heredoc *strings.Builder
		var file []byte
		mode := "op"
		buf := make([]byte, 0, 4096)
		rd := make([]byte, 4096)
		for {
			n, err := b.Read(rd)
			if err != nil {
				return
			}
			buf = append(buf, rd[:n]...)
			for {
				i := bytes.IndexByte(buf, '\r')
				if i < 0 {
					break
				}
				line := string(buf[:i])
				buf = buf[i+1:]
				reply := line
				switch {
				case heredoc != nil && line == "NUDANOS_EOF":
					file, _ = base64.StdEncoding.DecodeString(heredoc.String())
					heredoc = nil
					reply += op
				case heredoc != nil:
					heredoc.WriteString(line)
					reply += "\r\n> "
				case strings.HasPrefix(line, "base64 -d"):
					heredoc = &strings.Builder{}
					reply += "\r\n> "
				case strings.HasPrefix(line, "md5sum"):
					reply += fmt.Sprintf("\r\n%x  /tmp/ref.boot", md5.Sum(file)) + op
				case strings.HasPrefix(line, "cat /usr/share/vyatta-kernel-forwarding/dpdk-only-paths"):
					reply += "\r\n" + strings.ReplaceAll(paths, "\n", "\r\n") + strings.TrimPrefix(op, "\r\n")
				case strings.HasPrefix(line, hook+" "):
					reply += fmt.Sprintf("\r\nNUDANOS-BOOT-HOOK-STATUS=%d", hookStatus) + op
				case line == "show configuration commands":
					reply += "\r\n" + strings.ReplaceAll(show, "\n", "\r\n") + strings.TrimPrefix(op, "\r\n")
				case line == "configure":
					mode = "cfg"
					reply += cfg
				case mode == "cfg" && strings.HasPrefix(line, "exit"):
					mode = "op"
					reply += op
				case mode == "cfg":
					reply += cfg
				case mode == "op" && line == "exit": // logout
					mode = "user"
					reply += "\r\nnode login: "
				case mode == "user":
					mode = "pass"
					reply += "\r\nPassword: "
				case mode == "pass":
					mode = "op"
					reply = "" + op
				default:
					reply += op
				}
				mu.Lock()
				seen = append(seen, line)
				mu.Unlock()
				io.WriteString(b, reply)
			}
		}
	}()
	return topology.NewVM(topology.VMSpec{Name: "R1"}, boottest.NewConsole(a, &bytes.Buffer{}), func(time.Duration) {})
}

const refCommands = `set interfaces dataplane dp0s10 address '10.0.2.15/24'
set interfaces dataplane dp0s3 address '10.0.0.1/24'
set interfaces dataplane dp0s3 speed '100m'
set interfaces dataplane dp0s4 speed 'auto'
set protocols static route 10.9.0.0/16 next-hop '10.0.0.2'
set system host-name 'r1'
set system login user tmpuser level 'admin'
`

var ref = Ref{Name: "sampler/tuning", ConfigBoot: "system {\n\thost-name r1\n}\n", Commands: refCommands}

// A forced speed is set aside; a firewall or NAT policy is refused separately.
func TestCheckPassesWhenOnlySetAsideLinesDiffer(t *testing.T) {
	vm := fakeRouter(t, `set interfaces dataplane dp0s10 address '10.0.2.15/24'
set interfaces dataplane dp0s3 address '10.0.0.1/24'
set interfaces dataplane dp0s4 speed 'auto'
set protocols static route 10.9.0.0/16 next-hop '10.0.0.2'
set system host-name 'r1'
set system login user tmpuser level 'admin'
`)
	if f := Check(context.Background(), vm, []Ref{ref}, identity); len(f) != 0 {
		t.Fatalf("failures: %+v", f)
	}
}

func TestCheckReportsUnexpectedDifference(t *testing.T) {
	vm := fakeRouter(t, `set interfaces dataplane dp0s10 address '10.0.2.15/24'
set interfaces dataplane dp0s3 address '10.0.0.1/24'
set interfaces dataplane dp0s4 speed 'auto'
set system host-name 'r1'
set system login user tmpuser level 'admin'
`)
	f := Check(context.Background(), vm, []Ref{ref}, identity)
	if len(f) != 1 || f[0].Name != ref.Name || !strings.Contains(f[0].Detail, "set protocols static route 10.9.0.0/16 next-hop '10.0.0.2'") {
		t.Fatalf("failures = %+v; want the missing static route named", f)
	}
}

func TestPolicyFixtureIsNeverLoaded(t *testing.T) {
	policy := Ref{Name: "sampler/firewall", ConfigBoot: "security {\n\tfirewall {\n\t}\n}\n"}
	vm := fakeRouterHook(t, "", paths, 78)
	if f := Check(context.Background(), vm, []Ref{policy}, identity); len(f) != 0 {
		t.Fatalf("policy refusal was not recognized: %+v", f)
	}
	mu.Lock()
	defer mu.Unlock()
	for _, line := range seen {
		if line == "configure" || strings.HasPrefix(line, "load ") {
			t.Fatalf("attempted to load a refused configuration: %q", line)
		}
	}
}

func TestPolicyFixtureRejectsSuccessfulHook(t *testing.T) {
	policy := Ref{Name: "sampler/nat", ConfigBoot: "service {\n\tnat {\n\t}\n}\n"}
	vm := fakeRouterHook(t, "", paths, 0)
	f := Check(context.Background(), vm, []Ref{policy}, identity)
	if len(f) != 1 || !strings.Contains(f[0].Detail, "expected exit status 78") {
		t.Fatalf("successful migration of policy was not rejected: %+v", f)
	}
}

// The management address, host name and console users are the base
// configuration, which differs between the 2105 and NuDanOS images.
func TestCheckIgnoresBaseConfigLines(t *testing.T) {
	vm := fakeRouter(t, `set interfaces dataplane dp0s10 address dhcp
set interfaces dataplane dp0s3 address '10.0.0.1/24'
set interfaces dataplane dp0s4 speed 'auto'
set protocols static route 10.9.0.0/16 next-hop '10.0.0.2'
set system host-name 'nudanos'
set system login user nudanos level 'admin'
`)
	if f := Check(context.Background(), vm, []Ref{ref}, identity); len(f) != 0 {
		t.Fatalf("failures: %+v", f)
	}
}

// The reboot test boots a 2105 configuration with the administrator added,
// so it can log in afterwards.
func TestMergeBootAddsAdministrator(t *testing.T) {
	boot := "interfaces {\n\tdataplane dp0s3 {\n\t\tcpu-affinity 1\n\t}\n}\nsystem {\n\thost-name r1\n\tlogin {\n\t\tuser tmpuser {\n\t\t\tlevel admin\n\t\t}\n\t}\n}\n"
	got := mergeBoot(boot, adminBoot("nudanos", "pw"))
	want := "interfaces {\n\tdataplane dp0s3 {\n\t\tcpu-affinity 1\n\t}\n}\nsystem {\n\thost-name r1\n\tlogin {\n\t\tuser tmpuser {\n\t\t\tlevel admin\n\t\t}\n\t\tuser nudanos {\n\t\t\tauthentication {\n\t\t\t\tplaintext-password \"pw\"\n\t\t\t}\n\t\t\tlevel admin\n\t\t}\n\t}\n}\n"
	if got != want {
		t.Errorf("got:\n%s\nwant:\n%s", got, want)
	}
}

// Setting aside every child of a node leaves the node itself: NuDanOS shows
// a bare "set interfaces dataplane dp0s3" where 2105 had only a qos policy.
func TestCheckAcceptsParentOfSetAsideLines(t *testing.T) {
	r := Ref{Name: "sampler/qos", ConfigBoot: "x\n", Commands: "set interfaces dataplane dp0s3 policy qos 'SAMPLER'\nset policy qos name SAMPLER shaper bandwidth '100Mbit'\nset system time-zone 'UTC'\n"}
	vm := fakeRouterPaths(t, "set interfaces dataplane dp0s3\nset system time-zone 'UTC'\n", "interfaces * * policy\npolicy qos\n")
	if f := Check(context.Background(), vm, []Ref{r}, identity); len(f) != 0 {
		t.Fatalf("failures: %+v", f)
	}
}

// After the load check the administrator is no longer configured (and no
// longer in sudoers): the reboot test configures it again and logs in anew,
// since groups apply to a new login.
func TestRestoreAdminConfiguresAndLogsInAgain(t *testing.T) {
	vm := fakeRouter(t, "")
	if err := restoreAdmin(vm.Console, "nudanos", "pw", identity); err != nil {
		t.Fatal(err)
	}
	mu.Lock()
	got := strings.Join(seen, "|")
	mu.Unlock()
	want := "configure|set system login user nudanos authentication plaintext-password 'pw'|set system login user nudanos level superuser|commit|exit|exit|nudanos|pw|export VYATTA_PAGER=cat; stty cols 250"
	if got != want {
		t.Errorf("console:\n%s\nwant:\n%s", got, want)
	}
}
